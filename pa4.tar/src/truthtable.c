#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>



typedef struct list {
	char name[100];
	int x; 
	struct list *next;
}ll;



ll *createList(){
	ll *head = NULL;
	return head;
}



int insert(ll **head, char * name, int x)
{
	ll *now=*head; // current node is now pointing to the head 
	ll *addedItem=malloc(sizeof(ll)); //  allocate memory for new node
	strcpy(addedItem->name, name);
	
	addedItem->x=x;  // takes a data and put it in node 
	addedItem->next = NULL;

	if(!*head)
	{ // if list is emptty them the head is the new node 
		*head=addedItem;
		return 0;
	}

	while (now-> next != NULL)
	{
		now = now->next;
	}
	now->next = addedItem;




	return 0;

}



void prlist (ll *head)
{ 
	ll *now = head; // current is equal to head of list 

		while(now)
		{ // while current exists 
			printf("%s ", now->name);
			printf("%d \n", now->x); // print the data of curent 
			now=now->next; // nincrease the count of current by making it = to its next value 
		}


} // ends print list function





int * oneDArray( int in)

{
	int n = in;
	int *table;
	table=(int*) malloc(sizeof(int*)*n);
	return table;

}


int ** twoDArray ( int in, int out) 
{
int i = 0;
int n = in;
int up = 0001 << n;

int ** array;
	array=(int**) malloc(sizeof(int*)*up);
		for (i = 0; i < up; i++)
			{
				array[i]=(int*) malloc(sizeof(int)*(n+out+1));
			}
		return array;
}


int ** maketable ( int in , int out, int ** array, int * table)
{

	int i = 0;
	int k = 0;
	int num = 0;
	int n = in;
	int count = n;
	int up = 0001 << n;

	//printf("%d\n" , up);

	for ( i = 0; i < up; i++)
	{
		for (count = n;  count > 0; count--)
		{
			table [n-count] = i >> (count-1) & 0x01;
			num = table [n-count];

			array [i][ n-count] = num;
		}
	} // sets the left side to the right values using bit shifts 


for (i = 0; i < up; i++)
			{
				for ( k = n+1; k < (n+out+1); k++)
				{ 
					array[i][k] = 0;
				}
			}   // this loops sets the right side to zero 
	return array;
}


void printMatrix (int in , int out, int ** array)
{ 


int i = 0;
	int k =0;
	int num = 0;
	int n = in;
	int up = 0001 << n;




for (i = 0; i < up; i++)
			{
				for ( k = 0; k < (n+out+1); k++)
				{
					if (k==(n+out+1)-1)
						{
							num =array[i][k];
							printf("%d\n",num );
						}
					 		else if (k==(n))
					 			{
									printf("| ");
								}

									else
									{
										num = array[i][k];
										printf("%d ",num );
									}
		
				}
			} 

}



int main(int argc, char const *argv[])
{


ll *gates = createList(); // makes a linked list to store the gates and stuff after input and output 


char* c=malloc(100*sizeof(char));
char* wrd =malloc(1000*sizeof(char));


int in = 0 ;
int out = 0 ;
int i = 0;
char inc [6] = "INPUT";
char outc [7] = "OUTPUT";
int we = -1;
char line[100001];
char * word;

FILE * fp = fopen(argv[1], "r");
if (fp==NULL)
{
	printf("error\n");
	return 0;
} // prints error if the file pointer cannot open a file or the file does not exists 

if (fp!=NULL)
{
	ll *inList = createList(); // makes a linked list to store the inputs 
	ll *outList = createList(); // makes a linked list to store the outputs 



	/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */ 

	fscanf(fp,"INPUT %d",&in);
	insert(&inList,inc,in);

		for(i=0;i<in;i++)
			{
 				fscanf(fp," %s",c);
 				insert(&inList,c,i);
 			}

 	/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  this is to take the inputs and store thier names in the list */ 

	fscanf(fp,"\n");
	fscanf(fp,"OUTPUT %d ",&out);
	insert(&outList,outc,out);

		for(i=0;i<out;i++)
			{	
 				fscanf(fp," %s",c);
  				insert(&outList,c,in+i+1);
  			}
		fscanf(fp,"\n"); // makes the file pointer go to next line 


	/* ~~~~~~~~~~~~~~  this is to take the output and see how many we got and thier names and store it in a linked list  */ 


    while (EOF != fscanf(fp, "%100000[^\n]\n", line))
    	{
    		word = strtok (line," ");

    		  while (word != NULL)
  				{

						strcpy(wrd, word);
   						 word = strtok (NULL, " ");
   						 insert(&gates,wrd,we);
				}
 		} 

 /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~     this is to take down the words after input and output and store it in the linked list*/    



int * table = oneDArray(in); // make an 1 d array called table 
int ** array = twoDArray(in, out); // make an 2d array called array 
maketable(in,out,array,table); // makes the left side of the table and sets the right all to 0;
printMatrix ( in,out,array); // this just prints the matrix 


	return 0;	
}

return 0;

}









